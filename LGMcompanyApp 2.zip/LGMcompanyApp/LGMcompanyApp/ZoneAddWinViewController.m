
#import "ZoneAddWinViewController.h"

@interface ZoneAddWinViewController ()
{
    NSArray <NSString *> * strArr1,*strArr2,*strArr3,*strArr4;
    NSString *str1,*str2,*str3,*str4;

}

@end

@implementation ZoneAddWinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    strArr1 = @[@"Cat1", @"Cat2", @"Cat3"];
    strArr2 = @[@"M", @"B"];
    strArr3=@[@"Yes", @"No"];
    strArr4=@[@"Yes",@"No"];
    str1 = @"Category";
    str2 = @"M/B";
    str3=@"Fitness Station Prese";
    str4=@"Playground prese";
    // Do any additional setup after loading the view.
    
//    [commonUtils setImageViewAFNetworking:logoImageView withImageUrl:@"http://afrisia.info/backend/135.jpg" withPlaceholderImage:[UIImage imageNamed:@"logo1"]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)homepage_Button:(id)sender {
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
}

- (IBAction)register_Button:(id)sender {
    NSMutableDictionary *paramDic=[[NSMutableDictionary alloc]init];
    [paramDic setObject:zonename_txt.text forKey:@"zone_name"];
    [paramDic setObject:siteid_txt.text forKey:@"site_id"];
    [paramDic setObject:sitedescription_txt.text forKey:@"site_description"];
    [paramDic setObject:siteknowledge_txt.text forKey:@"site_knowledge"];
    [paramDic setObject:area_txt.text forKey:@"area"];
    [paramDic setObject:hectares_txt.text forKey:@"hectares"];
    [paramDic setObject:usbref_txt.text forKey:@"usbref"];
    [paramDic setObject:str1 forKey:@"category"];
    [paramDic setObject:str2 forKey:@"mb"];
    [paramDic setObject:str3 forKey:@"fitness_station_prese"];
    [paramDic setObject:str4 forKey:@"playground_prese"];
    [paramDic setObject:playgroundname_txt.text forKey:@"playground_name"];
    NSString *photo = [commonUtils encodeToBase64String:logoImageView.image byCompressionRatio:0.5];
    [paramDic setObject:photo forKey:@"site_image"];
    NSLog(@"%@",photo);

    
    [self requestAPIZonesinfoAdd:paramDic];
}

- (IBAction)camera_Button:(id)sender {
//    
//    UIViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"CameraWinViewController"];
//    [self.navigationController pushViewController:detail animated:YES];
    
    [self showAnimationView:photoSelectView];
    
    
}
#pragma mark - API Request - User ZonesinfoAdd
- (void)requestAPIZonesinfoAdd:(NSMutableDictionary *)dic {
    //    self.isLoadingUserBase = YES;
    [commonUtils showActivityIndicatorColored:self.view];
    [NSThread detachNewThreadSelector:@selector(requestDataZonesinfoAdd:) toTarget:self withObject:dic];
}

- (void)requestDataZonesinfoAdd:(id) params {
    NSDictionary *resObj = nil;
    resObj = [commonUtils httpJsonRequest:API_URL_ZONES_INFO_ADD withJSON:(NSMutableDictionary *) params];
    //    self.isLoadingUserBase = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        // code here
        [commonUtils hideActivityIndicator];     });
    
    
    //NSLog(@"Result%@", resObj);
    
    if (resObj != nil) {
        NSDictionary *result = (NSDictionary *)resObj;
        NSDecimalNumber *status = [result objectForKey:@"status"];
        if([status intValue] == 1) {
            //appController.currentUser = [result objectForKey:@"current_user"];
            //[commonUtils setUserDefaultDic:@"current_user" withDic:appController.currentUser];
            [self performSelector:@selector(requestOverZonesinfoAdd) onThread:[NSThread mainThread] withObject:nil waitUntilDone:YES];
        } else {
            NSString *msg = (NSString *)[resObj objectForKey:@"msg"];
            if([msg isEqualToString:@""]) msg = @"Please complete entire form";
            [commonUtils showVAlertSimple:@"Failed" body:msg duration:2.4];
        }
    } else {
        [commonUtils showVAlertSimple:@"Connection Error" body:@"Please check your internet connection status" duration:2.0];
    }
}

- (void)requestOverZonesinfoAdd {
    
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
}

- (NSInteger)numberOfComponentsInDropdownMenu:(MKDropdownMenu *)dropdownMenu {
    return 1;
}
- (NSInteger)dropdownMenu:(MKDropdownMenu *)dropdownMenu numberOfRowsInComponent:(NSInteger)component {
    if ([dropdownMenu viewWithTag:1]) {
        return 3;
    }else if ([dropdownMenu viewWithTag:2]){
        return 2;
    }else if ([dropdownMenu viewWithTag:3]){
        return 2;
    }else if ([dropdownMenu viewWithTag:4]){
        return 2;
    }
    return 0;
}
- (UIColor *)dropdownMenu:(MKDropdownMenu *)dropdownMenu backgroundColorForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [UIColor whiteColor];
}
- (void)dropdownMenu:(MKDropdownMenu *)dropdownMenu didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if([dropdownMenu viewWithTag:1]){
        str1 = [strArr1 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }else if ([dropdownMenu viewWithTag:2]){
        str2 = [strArr2 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }else if ([dropdownMenu viewWithTag:3]){
        str3 = [strArr3 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }else if ([dropdownMenu viewWithTag:4]){
        str4 = [strArr4 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }
}

- (UIView *)dropdownMenu:(MKDropdownMenu *)dropdownMenu viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *mLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width,  view.frame.size.height)];
    if ([dropdownMenu viewWithTag:1]) {
        [mLab setText:[strArr1 objectAtIndex:row]];
        NSString *str = [strArr1 objectAtIndex:row];
        return mLab;
    }else if ([dropdownMenu viewWithTag:2]){
        [mLab setText:[strArr2 objectAtIndex:row]];
        NSString *str = [strArr2 objectAtIndex:row];
        return mLab;
    }else if ([dropdownMenu viewWithTag:3]){
        [mLab setText:[strArr3 objectAtIndex:row]];
        NSString *str = [strArr3 objectAtIndex:row];
        return mLab;
    }else if ([dropdownMenu viewWithTag:4]){
        [mLab setText:[strArr4 objectAtIndex:row]];
        return mLab;
    }
    
                                                                                                                                    
    return mLab;
}
- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForComponent:(NSInteger)component {
    if ([dropdownMenu viewWithTag:1]){
    
    return [[NSAttributedString alloc] initWithString:str1
                                           attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                        NSForegroundColorAttributeName: [UIColor blackColor]}];
    }else if ([dropdownMenu viewWithTag:2]){
        return [[NSAttributedString alloc] initWithString:str2
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    }else if ([dropdownMenu viewWithTag:3]){
        return [[NSAttributedString alloc] initWithString:str3
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    }else if ([dropdownMenu viewWithTag:4]){
        return [[NSAttributedString alloc] initWithString:str4
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    }
    
    return  NULL;
}

- (void)showAnimationView:(UIView *) view{
    [UIView animateWithDuration:0.3 animations:^{
        view.frame = CGRectMake(view.frame.origin.x, self.view.frame.size.height-view.frame.size.height-10, view.frame.size.width, view.frame.size.height);
    } completion:^(BOOL finished) { }];
    
}

- (void)hideAnimationView:(UIView *) view{
    [UIView animateWithDuration:0.3 animations:^{
        view.frame = CGRectMake(view.frame.origin.x, self.view.frame.size.height, view.frame.size.width, view.frame.size.height);
    } completion:^(BOOL finished) { }];
    
}

- (IBAction)btnCancel_Clicked:(id)sender {
    [self hideAnimationView:photoSelectView];
}

- (IBAction)btnTakePhoto_Clicked:(id)sender {
    [self showCameraView];
}

- (IBAction)btnPhotoLibrary_Clicked:(id)sender {
    [self showPhotoLibrary];
}

- (void)showCameraView{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showPhotoLibrary{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [logoImageView setImage:info[UIImagePickerControllerEditedImage]];
    [picker dismissViewControllerAnimated:YES completion:nil];
    [self hideAnimationView:photoSelectView];
}

@end
