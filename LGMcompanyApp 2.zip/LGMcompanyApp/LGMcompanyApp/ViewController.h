//
//  ViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(IBAction)signup_Button:(id)sender;

-(IBAction)login_Button:(id)sender;

@end

