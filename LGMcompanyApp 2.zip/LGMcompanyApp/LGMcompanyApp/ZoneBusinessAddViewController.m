//
//  ZoneBusinessAddViewController.m
//  LGMcompanyApp
//
//  Created by ForStar on 9/4/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import "ZoneBusinessAddViewController.h"

@interface ZoneBusinessAddViewController ()
{
    NSArray <NSString *> * strArr1,*strArr2;
    NSString *str1,*str2;
}
@end

@implementation ZoneBusinessAddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    strArr1 = @[@"Cat1", @"Cat2", @"Cat3"];
    strArr2 = @[@"M", @"B"];
    str1 = @"Category";
    str2 = @"M/B";
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfComponentsInDropdownMenu:(MKDropdownMenu *)dropdownMenu {
    return 1;
}
- (NSInteger)dropdownMenu:(MKDropdownMenu *)dropdownMenu numberOfRowsInComponent:(NSInteger)component {
    if ([dropdownMenu viewWithTag:1]) {
        return 3;
    }else if ([dropdownMenu viewWithTag:2]){
        return 2;
    }
    return 0;
}
- (UIColor *)dropdownMenu:(MKDropdownMenu *)dropdownMenu backgroundColorForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [UIColor whiteColor];
}


- (void)dropdownMenu:(MKDropdownMenu *)dropdownMenu didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if([dropdownMenu viewWithTag:1]){
        str1 = [strArr1 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }else if ([dropdownMenu viewWithTag:2]){
        str2 = [strArr2 objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
    }
}
                                                                 
- (UIView *)dropdownMenu:(MKDropdownMenu *)dropdownMenu viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *mLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width,  view.frame.size.height)];
    if ([dropdownMenu viewWithTag:1]) {
        [mLab setText:[strArr1 objectAtIndex:row]];
        NSString *str = [strArr1 objectAtIndex:row];
        return mLab;
    }else if ([dropdownMenu viewWithTag:2]){
        [mLab setText:[strArr2 objectAtIndex:row]];
        NSString *str = [strArr2 objectAtIndex:row];
        return mLab;
    }
    return mLab;                                                                                                           
}
- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForComponent:(NSInteger)component {
    if ([dropdownMenu viewWithTag:1]){
        
        return [[NSAttributedString alloc] initWithString:str1
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    }else if ([dropdownMenu viewWithTag:2]){
        return [[NSAttributedString alloc] initWithString:str2
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    }
                                                                                                                                                                                                                                                              
    return  NULL;
}
                                                                                                                                               
- (IBAction)camera_Button:(id)sender {
    
    
//    UIViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"CameraWinViewController"];
//    [self.navigationController pushViewController:detail animated:YES];
    
     [self showAnimationView:photoSelectView];
}

- (void)showAnimationView:(UIView *) view{
    [UIView animateWithDuration:0.3 animations:^{
        view.frame = CGRectMake(view.frame.origin.x, self.view.frame.size.height-view.frame.size.height-10, view.frame.size.width, view.frame.size.height);
    } completion:^(BOOL finished) { }];
    
}

- (IBAction)btnCancel_Clicked:(id)sender {
    [self hideAnimationView:photoSelectView];
}
- (void)hideAnimationView:(UIView *) view{
    [UIView animateWithDuration:0.3 animations:^{
        view.frame = CGRectMake(view.frame.origin.x, self.view.frame.size.height, view.frame.size.width, view.frame.size.height);
    } completion:^(BOOL finished) { }];
    
}

- (IBAction)btnTakePhoto_Clicked:(id)sender {
    [self showCameraView];
}
- (void)showCameraView{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:picker animated:YES completion:nil];
}

- (IBAction)btnPhotoLibrary_Clicked:(id)sender {
    [self showPhotoLibrary];
}

- (void)showPhotoLibrary{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:picker animated:YES completion:nil];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    [logoImageView setImage:info[UIImagePickerControllerEditedImage]];
    [picker dismissViewControllerAnimated:YES completion:nil];
    [self hideAnimationView:photoSelectView];
}

- (IBAction)homepage_Button:(id)sender {
    
    UIViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
    
}

- (IBAction)register_Button:(id)sender {
    NSMutableDictionary *paramDic=[[NSMutableDictionary alloc] init];
    [paramDic setObject:daterunorder_txt.text forKey:@"date_runorder"];
    [paramDic setObject:siteid_txt.text forKey:@"site_id"];
    [paramDic setObject:sitedescription_txt.text forKey:@"site_description"];
    [paramDic setObject:siteknowledge_txt.text forKey:@"site_knowledge"];
    [paramDic setObject:area_txt.text forKey:@"area"];
    [paramDic setObject:hectares_txt.text forKey:@"hectares"];
    [paramDic setObject:datestarted_txt.text forKey:@"date_started"];
    [paramDic setObject:datecompleted_txt.text forKey:@"date_completed"];
    [paramDic setObject:usbref_txt.text forKey:@"usbref"];
    [paramDic setObject:handpruningm3_txt.text forKey:@"hand_pruningm3"];
    [paramDic setObject:greenwastem3_txt.text forKey:@"green_wastem3"];
    [paramDic setObject:citecut_txt.text forKey:@"site_cut"];
    [paramDic setObject:m2claimforinvoice_txt.text forKey:@"m2claim_forinvoice"];
    [paramDic setObject:comments_txt.text forKey:@"comment"];
    [paramDic setObject:str1 forKey:@"category"];
    [paramDic setObject:str2 forKey:@"mb"];
    NSString *photo = [commonUtils encodeToBase64String:logoImageView.image byCompressionRatio:0.5];
    [paramDic setObject:photo forKey:@"site_image"];
    
    [self requestAPIZonebusinessAdd:paramDic];
    
}
- (void)requestAPIZonebusinessAdd:(NSMutableDictionary *)dic {
    //    self.isLoadingUserBase = YES;
    [commonUtils showActivityIndicatorColored:self.view];
    [NSThread detachNewThreadSelector:@selector(requestDataZonebusinessAdd:) toTarget:self withObject:dic];
}
- (void)requestDataZonebusinessAdd:(id) params {
    NSDictionary *resObj = nil;
    resObj = [commonUtils httpJsonRequest:API_URL_ZONES_BUSINESS_ADD withJSON:(NSMutableDictionary *) params];
    //    self.isLoadingUserBase = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        // code here
        [commonUtils hideActivityIndicator];
    });
    
    
    NSLog(@"Result%@", resObj);
    
    if (resObj != nil) {
        NSDictionary *result = (NSDictionary *)resObj;
        NSDecimalNumber *status = [result objectForKey:@"status"];
        if([status intValue] == 1) {
            //appController.currentUser = [result objectForKey:@"current_user"];
            //[commonUtils setUserDefaultDic:@"current_user" withDic:appController.currentUser];
            [self performSelector:@selector(requestOverZonebusinessAdd) onThread:[NSThread mainThread] withObject:nil waitUntilDone:YES];
        } else {
            NSString *msg = (NSString *)[resObj objectForKey:@"msg"];
            if([msg isEqualToString:@""]) msg = @"Please complete entire form";
            [commonUtils showVAlertSimple:@"Failed" body:msg duration:2.4];
        }
    } else {
        [commonUtils showVAlertSimple:@"Connection Error" body:@"Please check your internet connection status" duration:2.0];
    }
}

- (void)requestOverZonebusinessAdd {
    
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
}


@end
