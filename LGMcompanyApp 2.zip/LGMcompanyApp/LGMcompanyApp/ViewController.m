//
//  ViewController.m
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //Get the stored data before the view loads
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *useremail=[defaults objectForKey:@"useremail"];
    NSString *userpassword=[defaults objectForKey:@"userpassword"];
    
    //Update the UI elements with the saved data
    if(![useremail  isEqual:@""] && ![userpassword  isEqual:@""]){
        UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
        [self.navigationController pushViewController:detail animated:YES];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)signup_Button:(id)sender{
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"SignupWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
}

-(IBAction)login_Button:(id)sender{
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"LoginWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
}
                                                                                                                                          
@end
