//
//  UIImage+fixOrientation.h
//  StatEdge
//
//  Created by Brendan Zhou on 26/11/2014.
//  Copyright (c) 2014 Bizar Mobile Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (fixOrientation)

- (UIImage *)fixOrientation;

@end
