//
//  CLResizeTool.h
//
//  Created by sho yakushiji on 2013/12/12.
//  Copyright (c) 2013年 CALACULU. All rights reserved.
//

#import "CLImageToolBase.h"

@interface CLResizeTool : CLImageToolBase

@end
