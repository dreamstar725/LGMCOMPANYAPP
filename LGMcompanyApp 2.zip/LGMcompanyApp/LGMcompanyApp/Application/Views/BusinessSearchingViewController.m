//
//  BusinessSearchingViewController.m
//  LGMcompanyApp
//
//  Created by ForStar on 9/4/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import "BusinessSearchingViewController.h"

@interface BusinessSearchingViewController ()
{
    NSArray <NSString *>  *strArr;
    NSString *str,*paramstr;
    NSMutableArray *businessoption;
    NSMutableArray *siteidarray;
}
@end

@implementation BusinessSearchingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    businessoption = [[NSMutableArray  alloc] init];
    siteidarray=[[NSMutableArray alloc] init];
    
    
    strArr=@[@"Zone Name",@"Site ID"];
    str = @"Search Option";
    
    
    // Do any additional setup after loading the view.
}


                                                                                                                                                                                                                                                                                                                                                                                                          

//table view implement/////////////////////////////////

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [businessoption count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleIdentifer=@"simpleresult";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:simpleIdentifer];
    if(cell==nil){
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleIdentifer];
        cell.backgroundColor=[UIColor orangeColor];

    }
    cell.textLabel.text=[businessoption objectAtIndex:indexPath.row];
    cell.textLabel.textColor=[UIColor whiteColor];
    cell.selectedTextColor=[UIColor redColor];
    cell.textLabel.font=[UIFont fontWithName:@"Arial" size:18.0f];
    cell.backgroundColor=[UIColor orangeColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    UIAlertView *messageAlert=[[UIAlertView alloc] initWithTitle:@"Row Selected" message:@"You've selected a row" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [messageAlert show];
//    
    paramstr=@"site_id";
    NSMutableDictionary *paramDic=[[NSMutableDictionary alloc] init];
    [paramDic setObject:paramstr forKey:@"field_name"];
    [paramDic setObject:[siteidarray objectAtIndex:indexPath.row] forKey:@"field_value"];
    NSLog(@"%@",[siteidarray objectAtIndex:indexPath.row]);
    
    [self requestAPISiteidFieldFilter:paramDic];
          
                                                                                                                                  
    
}
                                                                                                 
///////////////////////////////////////////////
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfComponentsInDropdownMenu:(MKDropdownMenu *)dropdownMenu {
    return 1;
}
- (NSInteger)dropdownMenu:(MKDropdownMenu *)dropdownMenu numberOfRowsInComponent:(NSInteger)component {
    return 2;
}
- (UIColor *)dropdownMenu:(MKDropdownMenu *)dropdownMenu backgroundColorForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [UIColor whiteColor];
}
- (void)dropdownMenu:(MKDropdownMenu *)dropdownMenu didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
        str = [strArr objectAtIndex:row];
        [dropdownMenu closeAllComponentsAnimated:YES];
        [self dropdownMenu:dropdownMenu attributedTitleForComponent:0];
        [dropdownMenu reloadAllComponents];
        [dropdownMenu setNeedsDisplay];
}

- (UIView *)dropdownMenu:(MKDropdownMenu *)dropdownMenu viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *mLab = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width,  view.frame.size.height)];
                                                                                                                                                                                                                            
        [mLab setText:[strArr objectAtIndex:row]];
        NSString *str = [strArr objectAtIndex:row];
        return mLab;
                                                                                                                                                                                                       
}
- (NSAttributedString *)dropdownMenu:(MKDropdownMenu *)dropdownMenu attributedTitleForComponent:(NSInteger)component {

        return [[NSAttributedString alloc] initWithString:str
                                               attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16 weight:UIFontWeightLight],
                                                            NSForegroundColorAttributeName: [UIColor blackColor]}];
    
}



- (IBAction)search_Button:(id)sender {
    
    if ([str isEqual:@"Zone Name"]) {
        
        paramstr=@"zone_name";
        NSMutableDictionary *paramDic = [[NSMutableDictionary alloc] init];
        
        [paramDic setObject:paramstr forKey:@"field_name"];
        [paramDic setObject:searchkey_txt.text forKey:@"field_value"];

        
        [self requestAPIZonenameFieldFilter:paramDic];
        
    }else if ([str isEqual:@"Site ID"]){
        
        paramstr=@"site_id";
        NSMutableDictionary *paramDic=[[NSMutableDictionary alloc] init];
        [paramDic setObject:paramstr forKey:@"field_name"];
        [paramDic setObject:searchkey_txt.text forKey:@"field_value"];

        [self requestAPISiteidFieldFilter:paramDic];
        
    }
}

                                                                           
#pragma mark - API Request - Zonename Field Filter
- (void)requestAPIZonenameFieldFilter:(NSMutableDictionary *)dic {
    //    self.isLoadingUserBase = YES;
    [commonUtils showActivityIndicatorColored:self.view];
    [NSThread detachNewThreadSelector:@selector(requestDataZonenameFieldFilter:) toTarget:self withObject:dic];
}

- (void)requestDataZonenameFieldFilter:(id) params {
    NSDictionary *resObj = nil;
    resObj = [commonUtils httpJsonRequest:API_URL_ZONESNAME_FIELD_FILTER withJSON:(NSMutableDictionary *) params];
    //    self.isLoadingUserBase = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        // code here
        [commonUtils hideActivityIndicator];
    });
    
    
  //  NSLog(@"Result%@", resObj);
    if (resObj != nil) {
        NSDictionary *result = (NSDictionary *)resObj;
        

 
        NSDecimalNumber *status = [result objectForKey:@"status"];
        
        if([status intValue] == 1) {
            
            
            NSDecimalNumber *indexnumber = [result objectForKey:@"i"];
            businessoption=[[NSMutableArray alloc] init];
            
            int index=0;
            do {
                NSString* indexkey=[@"index" stringByAppendingString:[NSString stringWithFormat:@"%i",index]];
                NSDictionary* data=(NSDictionary*)[result objectForKey:indexkey];
                NSString* str1=(NSString*)[data objectForKey:@"zone_name"];
                NSString* str2=(NSString*)[data objectForKey:@"site_id"];
                NSString* str3=(NSString*)[data objectForKey:@"site_description"];
                NSString* tempstr1=[str1 stringByAppendingString:@"    "];
                NSString* tempstr2=[tempstr1 stringByAppendingString:str2];
                NSString* tempstr3=[tempstr2 stringByAppendingString:@"    "];
                NSString* zonenamesearchresult=[tempstr3 stringByAppendingString:str3];
                [siteidarray addObject:str2];
                [businessoption addObject:zonenamesearchresult];
                index++;
            } while (index<[indexnumber intValue]);
            [tableview reloadData];

            [self performSelector:@selector(requestOverZonenameFieldFilter) onThread:[NSThread mainThread] withObject:nil waitUntilDone:YES];
        } else {
            NSString *msg = (NSString *)[resObj objectForKey:@"msg"];
            if([msg isEqualToString:@""]) msg = @"Please complete entire form";
            [commonUtils showVAlertSimple:@"Failed" body:msg duration:2.4];
        }
    } else {
        [commonUtils showVAlertSimple:@"Connection Error" body:@"Please check your internet connection status" duration:2.0];
    }
}

- (void)requestOverZonenameFieldFilter {
//    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
//    [self.navigationController pushViewController:detail animated:YES];
}


#pragma mark - API Request - Site ID Field Filter
- (void)requestAPISiteidFieldFilter:(NSMutableDictionary *)dic {
    //    self.isLoadingUserBase = YES;
    [commonUtils showActivityIndicatorColored:self.view];
    [NSThread detachNewThreadSelector:@selector(requestDataSiteidFieldFilter:) toTarget:self withObject:dic];
}

- (void)requestDataSiteidFieldFilter:(id) params {
    NSDictionary *resObj = nil;
    resObj = [commonUtils httpJsonRequest:API_URL_ZONESNAME_SITEID_FILTER withJSON:(NSMutableDictionary *) params];
    //    self.isLoadingUserBase = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        // code here
        [commonUtils hideActivityIndicator];
    });
                                                                             
    
    //NSLog(@"Result%@", resObj);
    
    if (resObj != nil) {
        NSDictionary *result = (NSDictionary *)resObj;

        NSDecimalNumber *status = [result objectForKey:@"status"];
        if([status intValue] == 1) {
            
            //Table View Reset/////
            businessoption=[[NSMutableArray alloc] init];
            NSDictionary* searchresultdata = (NSDictionary*)[result objectForKey:@"data"];
            NSString* str1=(NSString*)[searchresultdata objectForKey:@"date_runorder"];
            NSString* str2=(NSString*)[searchresultdata objectForKey:@"site_id"];
            NSString* str3=(NSString*)[searchresultdata objectForKey:@"site_description"];
            NSString* str4=(NSString*)[searchresultdata objectForKey:@"site_knowledge"];
            NSString* str5=(NSString*)[searchresultdata objectForKey:@"area"];
            NSString* str6=(NSString*)[searchresultdata objectForKey:@"hectares"];
            NSString* str7=(NSString*)[searchresultdata objectForKey:@"usbref"];
            NSString* str8=(NSString*)[searchresultdata objectForKey:@"category"];
            NSString* str9=(NSString*)[searchresultdata objectForKey:@"mb"];
            NSString* str10=(NSString*)[searchresultdata objectForKey:@"date_started"];
            NSString* str11=(NSString*)[searchresultdata objectForKey:@"date_completed"];
            NSString* str12=(NSString*)[searchresultdata objectForKey:@"hand_pruningm3"];
            NSString* str13=(NSString*)[searchresultdata objectForKey:@"green_wastem3"];
            NSString* str14=(NSString*)[searchresultdata objectForKey:@"site_cut"];
            NSString* str15=(NSString*)[searchresultdata objectForKey:@"m2claim_forinvoice"];
            NSString* str16=(NSString*)[searchresultdata objectForKey:@"comment"];
            NSString* str17=(NSString*)[searchresultdata objectForKey:@"site_image"];
            
            businessoption=[NSArray arrayWithObjects:[NSString stringWithFormat:@"%@%@",@"Date Run/Order     ",str1],[NSString stringWithFormat:@"%@%@",@"Site ID       ",str2],[NSString stringWithFormat:@"%@%@",@"Site Description     ",str3],[NSString stringWithFormat:@"%@%@",@"Site Knowledge     ",str4],[NSString stringWithFormat:@"%@%@",@"Area           ",str5],[NSString stringWithFormat:@"%@%@",@"Hectares    ",str6],[NSString stringWithFormat:@"%@%@",@"USBRef     ",str7],[NSString stringWithFormat:@"%@%@",@"Category       ",str8],[NSString stringWithFormat:@"%@%@",@"M/B            ",str9],[NSString stringWithFormat:@"%@%@",@"Date Started      ",str10],[NSString stringWithFormat:@"%@%@",@"Date Completed     ",str11],[NSString stringWithFormat:@"%@%@",@"Hand Pruning M3     ",str12],[NSString stringWithFormat:@"%@%@",@"Green Waste M3     ",str13],[NSString stringWithFormat:@"%@%@",@"Site Cut    ",str14],[NSString stringWithFormat:@"%@%@",@"M2 Claim for Invoice ",str15],[NSString stringWithFormat:@"%@%@",@"Commnets      ",str16],nil];
            [commonUtils setImageViewAFNetworking:logoImageView withImageUrl:str17 withPlaceholderImage:[UIImage imageNamed:@"logo1"]];
            
            [tableview reloadData];
            
            ////////////////////////
            
            
            [self performSelector:@selector(requestOverSiteidFieldFilter) onThread:[NSThread mainThread] withObject:nil waitUntilDone:YES];
        } else {
            NSString *msg = (NSString *)[resObj objectForKey:@"msg"];
            if([msg isEqualToString:@""]) msg = @"Please complete entire form";
            [commonUtils showVAlertSimple:@"Failed" body:msg duration:2.0];
        }                                                                                                                   
    } else {
        [commonUtils showVAlertSimple:@"Connection Error" body:@"Please check your internet connection status" duration:2.0];
    }
}

- (void)requestOverSiteidFieldFilter {

}
-(void)homepage_Button:(id)sender{
    UIViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
}


@end
