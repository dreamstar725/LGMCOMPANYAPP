//
//  BusinessSearchingViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/4/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MKDropdownMenu.h";

@interface BusinessSearchingViewController : UIViewController<UITextFieldDelegate,MKDropdownMenuDelegate,MKDropdownMenuDataSource,UITableViewDelegate,UITableViewDataSource>

{
    

    IBOutlet UITableView *tableview;

    IBOutlet UITextField *searchkey_txt;
        IBOutlet UIImageView *logoImageView;
    
}

- (IBAction)search_Button:(id)sender;
-(IBAction)homepage_Button:(id)sender;




@end
