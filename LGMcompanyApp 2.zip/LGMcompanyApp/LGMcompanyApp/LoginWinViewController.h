//
//  LoginWinViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginWinViewController : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
{
    
    IBOutlet UITextField *useremail_txt;
    IBOutlet UITextField *userpassword_txt;
    IBOutlet UIImageView *checkstate_img;
    IBOutlet MKMapView *mapView;
    BOOL isstate;
    
    
    
}

- (IBAction)rememberme_Button:(id)sender;

- (IBAction)login_Button:(id)sender;

- (IBAction)back_Button:(id)sender;

@end
