//
//  CameraWinViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/8/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CameraWinViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (strong, nonatomic) IBOutlet UIImageView *cameraimageview;

- (IBAction)takephoto_Button:(id)sender;
- (IBAction)selectphoto_Button:(id)sender;

@end
