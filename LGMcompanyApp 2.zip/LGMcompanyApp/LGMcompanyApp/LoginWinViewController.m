

#import "LoginWinViewController.h"
#import <CoreLocation/CoreLocation.h>
#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

@interface LoginWinViewController (){
    CLLocationManager *locationManager;
}

@end

@implementation LoginWinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isstate=false;
    // Do any additional setup after loading the view.
    self->mapView.showsUserLocation = YES;
    self->mapView.mapType = MKMapTypeHybrid;
    //self->mapView.mapType =MKMapTypeStandard;
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    if(IS_OS_8_OR_LATER) {
        [locationManager requestAlwaysAuthorization];
    }
    
    [locationManager startUpdatingLocation];
}

- (void)mapView:(MKMapView *)aMapView didUpdateUserLocation:(MKUserLocation *)aUserLocation {
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta = 0.005;
    span.longitudeDelta = 0.005;
    CLLocationCoordinate2D location;
    location.latitude = aUserLocation.coordinate.latitude;
    location.longitude = aUserLocation.coordinate.longitude;
    region.span = span;
    region.center = location;
    [aMapView setRegion:region animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)rememberme_Button:(id)sender {
    if(isstate){
        [checkstate_img setImage:[UIImage imageNamed:@"uncheck_img.png"]];
        isstate=false;
    }else{
        [checkstate_img setImage:[UIImage imageNamed:@"check_img.png"]];
        isstate=true;
    }
}

- (IBAction)login_Button:(id)sender {
    
    NSMutableDictionary *paramDic = [[NSMutableDictionary alloc] init];
    
    [paramDic setObject:useremail_txt.text forKey:@"user_email"];
    [paramDic setObject:userpassword_txt.text forKey:@"user_password"];
    
    [self requestAPILogIn:paramDic];
                                                                                                         
}
#pragma mark - API Request - User LogIn
- (void)requestAPILogIn:(NSMutableDictionary *)dic {
    //    self.isLoadingUserBase = YES;
    [commonUtils showActivityIndicatorColored:self.view];
    [NSThread detachNewThreadSelector:@selector(requestDataLogIn:) toTarget:self withObject:dic];
}

- (void)requestDataLogIn:(id) params {
    NSDictionary *resObj = nil;
    resObj = [commonUtils httpJsonRequest:API_URL_USER_LOGIN withJSON:(NSMutableDictionary *) params];
    //    self.isLoadingUserBase = NO;
    dispatch_async(dispatch_get_main_queue(), ^{
        // code here
        [commonUtils hideActivityIndicator];
    });
    
    
    NSLog(@"Result%@", resObj);
    if (resObj != nil) {
        NSDictionary *result = (NSDictionary *)resObj;
        NSDecimalNumber *status = [result objectForKey:@"status"];
        if([status intValue] == 1) {
            //            appController.currentUser = [result objectForKey:@"current_user"];
            //            [commonUtils setUserDefaultDic:@"current_user" withDic:appController.currentUser];
            
            if(isstate){
                // Hide the keyboard
//                [useremail_txt resignFirstResponder];
//                [userpassword_txt resignFirstResponder];
                //[ageTextField resignFirstResponder];
                
                // Create strings and integer to store the text info
                NSString *useremail = [useremail_txt text];
                NSString *userpassword  = [userpassword_txt text];
                //       int age = [[ageTextField text] integerValue];
                
                // Create instances of NSData
                //        UIImage *contactImage = contactImageView.image;
                //        NSData *imageData = UIImageJPEGRepresentation(contactImage, 100);
                
                
                // Store the data
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                
                [defaults setObject:useremail forKey:@"useremail"];
                [defaults setObject:userpassword forKey:@"userpassword"];
                //        [defaults setInteger:age forKey:@"age"];
                //        [defaults setObject:imageData forKey:@"image"];
                
                [defaults synchronize];
                
                NSLog(@"Data saved");
                
            }
            
                                                                                                                                                                                     
            [self performSelector:@selector(requestOverLogIn) onThread:[NSThread mainThread] withObject:nil waitUntilDone:YES];
        } else {
            NSString *msg = (NSString *)[resObj objectForKey:@"msg"];
            if([msg isEqualToString:@""]) msg = @"Please complete entire form";
            [commonUtils showVAlertSimple:@"Failed" body:msg duration:2.4];
        }
    } else {
        [commonUtils showVAlertSimple:@"Connection Error" body:@"Please check your internet connection status" duration:2.0];
    }
}

- (void)requestOverLogIn {
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"WorkSelectWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
}

                                                                                                                                                      

- (IBAction)back_Button:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];

}
@end
