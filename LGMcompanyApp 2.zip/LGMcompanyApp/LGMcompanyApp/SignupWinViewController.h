//
//  SignupWinViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface SignupWinViewController : UIViewController<MKMapViewDelegate,CLLocationManagerDelegate>
    {
    IBOutlet UITextField *username_txt;
    IBOutlet UITextField *useremail_txt;
    IBOutlet UITextField *userpassword_txt;
    IBOutlet UIImageView *checkstate_img;
    IBOutlet MKMapView *mapView;
    BOOL isstate;
    }

-(IBAction) back_Button:(id)sender;
- (IBAction)signup_Button:(id)sender;
- (IBAction)rememberme_Button:(id)sender;



@end
