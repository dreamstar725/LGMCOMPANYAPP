//
//  ZoneBusinessAddViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/4/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MKDropdownMenu.h"

@interface ZoneBusinessAddViewController : UIViewController<UITextFieldDelegate,MKDropdownMenuDelegate,MKDropdownMenuDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    
    IBOutlet UITextField *daterunorder_txt;
    IBOutlet UITextField *greenwastem3_txt;
    
    IBOutlet UITextField *comments_txt;
    IBOutlet UITextField *m2claimforinvoice_txt;
    IBOutlet UITextField *citecut_txt;
    IBOutlet UITextField *handpruningm3_txt;
    IBOutlet UITextField *datecompleted_txt;
    IBOutlet UITextField *datestarted_txt;
    IBOutlet UITextField *usbref_txt;
    IBOutlet UITextField *hectares_txt;
    IBOutlet UITextField *area_txt;
    IBOutlet UITextField *siteknowledge_txt;
    IBOutlet UITextField *sitedescription_txt;
    IBOutlet UITextField *siteid_txt;
    
    IBOutlet UIView *photoSelectView;
    IBOutlet UIImageView *logoImageView;
}

- (IBAction)camera_Button:(id)sender;

- (IBAction)homepage_Button:(id)sender;

- (IBAction)register_Button:(id)sender;

@end
