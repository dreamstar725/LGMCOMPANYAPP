//
//  WorkSelectWinViewController.m
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import "WorkSelectWinViewController.h"

@interface WorkSelectWinViewController ()

@end

@implementation WorkSelectWinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

}
                                                                                                                                                   
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation                                                                                                                                                                                                                                                

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)logout_Button:(id)sender {
    
    
    
    // Create strings and integer to store the text info
    NSString *useremail=@"";
    NSString *userpassword=@"";
    //       int age = [[ageTextField text] integerValue];
    
    // Create instances of NSData
    //        UIImage *contactImage = contactImageView.image;
    //        NSData *imageData = UIImageJPEGRepresentation(contactImage, 100);
    
    
    // Store the data
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setObject:useremail forKey:@"useremail"];
    [defaults setObject:userpassword forKey:@"userpassword"];
    //        [defaults setInteger:age forKey:@"age"];
    //        [defaults setObject:imageData forKey:@"image"];
    
    [defaults synchronize];
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"MainWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
                                                                                                                                                                                                                                                                                                                                                                                                                          

}

- (IBAction)addzoneinfo_Button:(id)sender {
    [checkstate0_img setImage:[UIImage imageNamed:@"radio_btn"]];
    UIViewController * detail = [self.storyboard instantiateViewControllerWithIdentifier: @"ZoneAddWinViewController"];
    [self.navigationController pushViewController:detail animated:YES];
    
}

- (IBAction)addbusiness_Button:(id)sender {
    [checkstate1_img setImage:[UIImage imageNamed:@"radio_btn"]];
    UIViewController  *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"ZoneBusinessAddViewController"];
    [self.navigationController pushViewController:detail animated:YES];
}

- (IBAction)searchinfo_Button:(id)sender {
    [checkstate2_img setImage:[UIImage imageNamed:@"radio_btn"]];
    UIViewController  *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"BusinessSearchingViewController"];
    [self.navigationController pushViewController:detail animated:YES];
}
@end
