//
//  ZoneAddWinViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MKDropdownMenu.h"

@interface ZoneAddWinViewController : UIViewController< UITextFieldDelegate, MKDropdownMenuDataSource, MKDropdownMenuDelegate, UIImagePickerControllerDelegate,UINavigationControllerDelegate> {
    IBOutlet UITextField *zonename_txt;
    IBOutlet UITextField *siteid_txt;
    IBOutlet UITextField *sitedescription_txt;
    IBOutlet UITextField *siteknowledge_txt;
    IBOutlet UITextField *area_txt;
    IBOutlet UITextField *hectares_txt;
    IBOutlet UITextField *usbref_txt;
    IBOutlet UITextField *playgroundname_txt;
    IBOutlet UIView *photoSelectView;
    IBOutlet UIImageView *logoImageView;
    
    
}


- (IBAction)homepage_Button:(id)sender;
- (IBAction)register_Button:(id)sender;

- (IBAction)camera_Button:(id)sender;

@end
