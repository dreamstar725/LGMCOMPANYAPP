//
//  WorkSelectWinViewController.h
//  LGMcompanyApp
//
//  Created by ForStar on 9/1/16.
//  Copyright © 2016 ForStar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WorkSelectWinViewController : UIViewController

{
    
    IBOutlet UIImageView *checkstate1_img;
    IBOutlet UIImageView *checkstate0_img;
    
    IBOutlet UIImageView *checkstate2_img;

}

- (IBAction)logout_Button:(id)sender;

- (IBAction)addzoneinfo_Button:(id)sender;
- (IBAction)addbusiness_Button:(id)sender;
- (IBAction)searchinfo_Button:(id)sender;

@end
